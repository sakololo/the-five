'use client';

import { useState, useEffect, useCallback } from 'react';
import Script from 'next/script';

// Types
interface Book {
  id: number;
  title: string;
  author: string;
  coverUrl: string;
  volumeNumber: number | null;
}

interface SelectedBook {
  manga: Book;
  volume: number;
}

interface AppraisalResult {
  soulTitle: string;
  analysis: string;
}

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const [books, setBooks] = useState<Book[]>([]);
  const [selectedBooks, setSelectedBooks] = useState<SelectedBook[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [mode, setMode] = useState<'with-title' | 'without-title'>('with-title');
  const [showAppraisalModal, setShowAppraisalModal] = useState(false);
  const [isAppraising, setIsAppraising] = useState(false);
  const [appraisalResult, setAppraisalResult] = useState<AppraisalResult | null>(null);
  const [displayedTitle, setDisplayedTitle] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  // Debounced search
  const searchBooks = useCallback(async (query: string) => {
    if (!query.trim()) {
      setBooks([]);
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
      const data = await response.json();

      if (data.books) {
        setBooks(data.books);
      }
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      searchBooks(searchQuery);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery, searchBooks]);

  const toggleBookSelection = (book: Book) => {
    const isSelected = selectedBooks.some(sb => sb.manga.id === book.id);

    if (isSelected) {
      setSelectedBooks(prev => prev.filter(sb => sb.manga.id !== book.id));
    } else if (selectedBooks.length < 5) {
      setSelectedBooks(prev => [...prev, { manga: book, volume: book.volumeNumber || 1 }]);
    }
  };

  const startAppraisal = async () => {
    if (selectedBooks.length !== 5) return;

    setShowAppraisalModal(true);
    setIsAppraising(true);
    setAppraisalResult(null);
    setDisplayedTitle('');

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          books: selectedBooks.map(sb => ({
            title: sb.manga.title,
            author: sb.manga.author,
            coverUrl: sb.manga.coverUrl,
          })),
        }),
      });

      const data = await response.json();

      if (data.fallback) {
        // AI failed, show fallback message
        showToastMessage(data.message);
        setMode('without-title');
        setShowAppraisalModal(false);
        return;
      }

      setAppraisalResult(data);

      // Typing effect for soul title
      for (let i = 0; i <= data.soulTitle.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 100));
        setDisplayedTitle(data.soulTitle.slice(0, i));
      }
    } catch (error) {
      console.error('Appraisal error:', error);
      showToastMessage('AI鑑定中にエラーが発生しました。シンプルモードをお試しください。');
      setShowAppraisalModal(false);
    } finally {
      setIsAppraising(false);
    }
  };

  const showToastMessage = (message: string) => {
    setToastMessage(message);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 4000);
  };

  const saveImage = async (type: 'full' | 'simple') => {
    const cardId = type === 'full' ? 'share-card-full' : 'share-card-simple';
    const card = document.getElementById(cardId);
    if (!card || typeof window === 'undefined') return;

    try {
      // @ts-expect-error html2canvas is loaded via script
      const canvas = await window.html2canvas(card, {
        scale: 3,
        useCORS: true,
        allowTaint: true,
        backgroundColor: type === 'simple' ? '#FAF9F6' : null,
      });

      canvas.toBlob((blob: Blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `the-five-${type}-${Date.now()}.png`;
        a.click();
        URL.revokeObjectURL(url);
        showToastMessage('画像を保存しました！');
      }, 'image/png');
    } catch (error) {
      console.error('Image save error:', error);
      showToastMessage('画像の保存中にエラーが発生しました。');
    }
  };

  return (
    <>
      <Script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js" />

      <div className="min-h-screen">
        {/* Header */}
        <header className="relative z-10 py-8 px-4">
          <div className="max-w-4xl mx-auto flex flex-col items-center gap-6">
            {/* Logo */}
            <div className="text-center">
              <h1
                className="text-5xl font-bold tracking-wide"
                style={{
                  fontFamily: "'Permanent Marker', cursive",
                  fontStyle: 'italic',
                  transform: 'skewX(-8deg)',
                }}
              >
                THE FIVE
              </h1>
              <p
                className="mt-2 text-sm opacity-70"
                style={{ fontFamily: "'Kaisei Tokumin', serif", letterSpacing: '0.12em' }}
              >
                私を形作る、5つの物語。
              </p>
            </div>

            {/* Description */}
            <div className="max-w-lg text-center px-4">
              <p
                className="text-sm leading-relaxed opacity-80"
                style={{ fontFamily: "'Kaisei Tokumin', serif" }}
              >
                好きなマンガ、そして人生で最も記憶に残っている5冊を選んでください。5つの表紙を1枚の美しい画像にまとめるとともに、AIがあなたの感性を読み解き、特別な「二つ名」を命名します。
              </p>
              <p
                className="text-xs mt-2 opacity-50"
                style={{ fontFamily: "'Kaisei Tokumin', serif" }}
              >
                ※AIによる命名のない5冊の表紙だけの画像も作れます。
              </p>
            </div>

            {/* Mode Toggle */}
            <div className="flex flex-col items-center gap-1">
              <p className="text-xs text-gray-400">モードを選択</p>
              <div className="glass-card flex rounded-full p-1 gap-1">
                <button
                  onClick={() => setMode('with-title')}
                  className={`px-4 py-2 rounded-full text-xs font-medium transition-all ${mode === 'with-title'
                      ? 'bg-white shadow-md font-semibold text-gray-800'
                      : 'text-gray-500 hover:text-gray-700'
                    }`}
                >
                  二つ名あり
                </button>
                <button
                  onClick={() => setMode('without-title')}
                  className={`px-4 py-2 rounded-full text-xs font-medium transition-all ${mode === 'without-title'
                      ? 'bg-white shadow-md font-semibold text-gray-800'
                      : 'text-gray-500 hover:text-gray-700'
                    }`}
                >
                  二つ名なし
                </button>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="relative z-10 max-w-5xl mx-auto px-4 py-4">
          {/* Selected Books Preview */}
          <section className="mb-8">
            <div className="glass-card rounded-3xl p-6 relative overflow-hidden min-h-[300px]">
              <div className="text-center mb-4">
                <span className="text-sm font-medium text-gray-600">
                  {selectedBooks.length} / 5 冊選択中
                </span>
              </div>

              <div className="flex justify-center gap-4 flex-wrap">
                {selectedBooks.map((sb, index) => (
                  <div
                    key={sb.manga.id}
                    className="w-20 h-28 rounded-lg overflow-hidden shadow-lg book-shadow cursor-pointer hover:scale-105 transition-transform"
                    style={{ transform: `rotate(${(index - 2) * 3}deg)` }}
                    onClick={() => toggleBookSelection(sb.manga)}
                  >
                    <img
                      src={sb.manga.coverUrl || 'https://placehold.co/150x220/gray/white?text=No+Image'}
                      alt={sb.manga.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
                {Array.from({ length: 5 - selectedBooks.length }).map((_, i) => (
                  <div
                    key={`empty-${i}`}
                    className="w-20 h-28 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center text-gray-400"
                  >
                    <span className="text-2xl">+</span>
                  </div>
                ))}
              </div>

              {/* Action Button */}
              <div className="mt-6 text-center">
                <button
                  onClick={mode === 'with-title' ? startAppraisal : () => saveImage('simple')}
                  disabled={selectedBooks.length !== 5}
                  className={`px-8 py-3 rounded-xl font-semibold transition-all ${selectedBooks.length === 5
                      ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg hover:from-amber-600 hover:to-orange-600'
                      : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    }`}
                >
                  {mode === 'with-title' ? '🔮 AI鑑定を開始' : '📷 画像を保存'}
                </button>
              </div>
            </div>
          </section>

          {/* Search Section */}
          <section className="mb-8">
            <div className="glass-card rounded-2xl p-4">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="マンガのタイトルを検索..."
                className="w-full px-4 py-3 rounded-xl bg-white/50 border border-gray-200 focus:outline-none focus:ring-2 focus:ring-amber-400"
              />
            </div>
          </section>

          {/* Search Results */}
          <section>
            {isLoading ? (
              <div className="text-center py-12">
                <div className="loading-pulse inline-block">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
                    <span className="text-2xl">📚</span>
                  </div>
                </div>
                <p className="mt-4 text-gray-500">検索中...</p>
              </div>
            ) : books.length > 0 ? (
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-4">
                {books.map((book) => {
                  const isSelected = selectedBooks.some(sb => sb.manga.id === book.id);
                  return (
                    <div
                      key={book.id}
                      onClick={() => toggleBookSelection(book)}
                      className={`cursor-pointer rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all ${isSelected ? 'ring-4 ring-amber-400 selected-glow' : ''
                        }`}
                    >
                      <img
                        src={book.coverUrl || 'https://placehold.co/150x220/gray/white?text=No+Image'}
                        alt={book.title}
                        className="w-full aspect-[3/4] object-cover"
                      />
                      <div className="p-2 bg-white/80">
                        <p className="text-xs font-medium truncate">{book.title}</p>
                        <p className="text-xs text-gray-500 truncate">{book.author}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : searchQuery ? (
              <div className="text-center py-12 text-gray-500">
                検索結果がありません
              </div>
            ) : (
              <div className="text-center py-12 text-gray-400">
                マンガを検索して5冊選んでください
              </div>
            )}
          </section>
        </main>

        {/* Simple Share Card (hidden, for capture) */}
        <div id="share-card-simple" className="fixed -left-[9999px]" style={{ width: 600, height: 338 }}>
          <div className="w-full h-full flex flex-col justify-center items-center gap-6 p-6" style={{ backgroundColor: '#FAF9F6' }}>
            <div className="text-center">
              <h2
                className="text-3xl font-bold"
                style={{ fontFamily: "'Permanent Marker', cursive", fontStyle: 'italic', transform: 'skewX(-8deg)', color: '#1A1A1A' }}
              >
                THE FIVE
              </h2>
              <p style={{ fontFamily: "'Kaisei Tokumin', serif", fontSize: 11, color: '#1A1A1A', opacity: 0.6, marginTop: 4 }}>
                私を形作る、5つの物語。
              </p>
            </div>
            <div className="flex gap-3">
              {selectedBooks.map((sb) => (
                <div key={sb.manga.id} className="w-16 h-24 rounded-lg overflow-hidden shadow-lg">
                  <img src={sb.manga.coverUrl} alt={sb.manga.title} className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Appraisal Modal */}
        {showAppraisalModal && (
          <div className={`modal fixed inset-0 z-50 flex items-center justify-center p-4 ${showAppraisalModal ? 'open' : ''}`}>
            <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-indigo-900 to-purple-900" />
            <div className="modal-content relative w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              {isAppraising ? (
                <div className="text-center py-20">
                  <div className="loading-pulse inline-block mb-6">
                    <div className="w-24 h-24 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-2xl">
                      <span className="text-4xl">📚</span>
                    </div>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">あなたの魂を鑑定中...</h3>
                  <p className="text-white/60 text-sm">選ばれた5冊から、あなたの本質を読み解いています</p>
                </div>
              ) : appraisalResult && (
                <div>
                  {/* Full Share Card */}
                  <div id="share-card-full" className="relative mx-auto rounded-2xl overflow-hidden" style={{ width: 600, height: 338 }}>
                    <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-indigo-900 to-purple-900" />
                    <div className="relative z-10 h-full flex flex-col justify-between p-6">
                      <div className="text-center">
                        <p className="text-white/50 text-xs tracking-widest uppercase mb-2">YOUR SOUL NAME</p>
                        <h2 className="text-3xl font-black text-white drop-shadow-lg">{appraisalResult.soulTitle}</h2>
                      </div>
                      <div className="flex justify-center gap-2">
                        {selectedBooks.map((sb) => (
                          <div key={sb.manga.id} className="w-14 h-20 rounded shadow-lg overflow-hidden border-2 border-white/30">
                            <img src={sb.manga.coverUrl} alt={sb.manga.title} className="w-full h-full object-cover" />
                          </div>
                        ))}
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 bg-gradient-to-br from-amber-600 to-amber-800 rounded-lg flex items-center justify-center">
                            <span className="text-white text-xs font-black">本棚</span>
                          </div>
                          <span className="text-white font-bold text-sm">THE FIVE</span>
                        </div>
                        <p className="text-white/40 text-xs">2026.01</p>
                      </div>
                    </div>
                  </div>

                  {/* Title Display */}
                  <div className="text-center py-4">
                    <h2 className="text-4xl font-black text-white drop-shadow-lg">
                      {displayedTitle}
                      <span className="typing-cursor text-amber-400" />
                    </h2>
                  </div>

                  {/* Analysis */}
                  <div className="glass-card rounded-2xl p-6 mx-4 mb-6">
                    <h4 className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
                      <span>🔮</span> AI鑑定結果
                    </h4>
                    <p className="text-gray-600 text-sm leading-relaxed">{appraisalResult.analysis}</p>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-col items-center gap-4 pb-8">
                    <p className="text-white/60 text-xs">画像の種類を選択</p>
                    <div className="flex gap-3">
                      <button
                        onClick={() => saveImage('full')}
                        className="px-5 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-xl font-semibold shadow-lg hover:from-amber-600 hover:to-orange-600 transition flex items-center gap-2"
                      >
                        <span>📝</span> フルバージョン
                      </button>
                      <button
                        onClick={() => saveImage('simple')}
                        className="px-5 py-3 bg-white/20 hover:bg-white/30 text-white rounded-xl font-medium transition flex items-center gap-2 border border-white/30"
                      >
                        <span>📷</span> シンプル
                      </button>
                    </div>
                    <button
                      onClick={() => setShowAppraisalModal(false)}
                      className="text-white/50 hover:text-white text-sm mt-2 transition"
                    >
                      閉じる
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Toast */}
        {showToast && (
          <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[70] animate-bounce">
            <div className="glass-card px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3">
              <span className="text-2xl">✅</span>
              <p className="font-medium text-gray-800">{toastMessage}</p>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
